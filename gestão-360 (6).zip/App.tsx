import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './views/Dashboard';
import { Transactions } from './views/Transactions';
import { Clients } from './views/Clients';
import { Wallet } from './views/Wallet';
import { FamilyManagement } from './views/FamilyManagement';
import { Login } from './views/Login';
import { AppView, Transaction, Client, EntityType, TransactionType, PaymentStatus, Card, AppNotification, Account, PaymentMethodType, RecurringExpense, User } from './types';
import { getFinancialMonth } from './utils/dateHelpers';
import { Bell, Menu, ChevronDown, LogOut, Cloud, CloudOff, Database, Loader2, HardDrive, Rocket, CheckCircle2 } from 'lucide-react';

// FIREBASE IMPORTS
import { db } from './services/firebase';
import { 
  collection, 
  onSnapshot, 
  doc, 
  deleteDoc, 
  writeBatch, 
  setDoc,
  increment,
  updateDoc
} from 'firebase/firestore';

// Users Configuration
const USERS: User[] = [
  { id: 'u1', name: 'Eliú', initials: 'EL', color: 'bg-indigo-600' },
  { id: 'u2', name: 'Leticia', initials: 'LE', color: 'bg-rose-600' }
];

// --- INITIAL DATA FOR MIGRATION/SEEDING ---

const INITIAL_CARDS: Card[] = [
  { id: 'card1', name: 'Itaú Azul Platinum - Principal', limit: 15000, closingDay: 15, dueDay: 23, currentInvoice: 0 },
  { id: 'card2', name: 'C6 Carbon - Transição', limit: 10000, closingDay: 16, dueDay: 24, currentInvoice: 0 },
  { id: 'card3', name: 'Nubank - Eliú', limit: 5000, closingDay: 16, dueDay: 24, currentInvoice: 0 },
  { id: 'card4', name: 'Rico - Leticia', limit: 5000, closingDay: 17, dueDay: 25, currentInvoice: 0 },
];

const INITIAL_ACCOUNTS: Account[] = [
  { id: 'acc1', name: 'PJ - Equipe da Piscina', type: 'BANK', balance: 0.00, entityId: EntityType.MEI1 },
  { id: 'acc2', name: 'PJ - EP Manutenção', type: 'BANK', balance: 0.00, entityId: EntityType.MEI2 },
  { id: 'acc3', name: 'Dinheiro Físico', type: 'CASH', balance: 0.00, entityId: EntityType.FAMILY },
  { id: 'acc4', name: 'Itaú Azul - Eliú', type: 'BANK', balance: 0.00, entityId: EntityType.FAMILY },
  { id: 'acc5', name: 'C6 - Eliú', type: 'BANK', balance: 0.00, entityId: EntityType.FAMILY },
  { id: 'acc6', name: 'Caixa - Eliú', type: 'BANK', balance: 0.00, entityId: EntityType.FAMILY },
  { id: 'acc7', name: '99 - Eliú', type: 'BANK', balance: 0.00, entityId: EntityType.FAMILY },
  { id: 'acc8', name: 'Mercado Pago - Eliú', type: 'BANK', balance: 0.00, entityId: EntityType.FAMILY },
  { id: 'acc9', name: 'Reserva Emergência - MP Leticia', type: 'BANK', balance: 0.00, entityId: EntityType.FAMILY },
  { id: 'acc10', name: 'Reserva Física - Emergência', type: 'CASH', balance: 0.00, entityId: EntityType.FAMILY },
];

const INITIAL_CLIENTS: Client[] = [
  // --- MEI 1 (acc1) ---
  { id: 'cli01', name: 'Fábio - Cond. Vista Bella', recurringValue: 170.00, fixedPayDay: 2, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli02', name: 'Lucas Djalma - Cond. Ypê Branco', recurringValue: 260.00, fixedPayDay: 10, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli03', name: 'Diego - Cond. Santa Luzia', recurringValue: 200.00, fixedPayDay: 10, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli04', name: 'Mateus - Jd. Independência', recurringValue: 180.00, fixedPayDay: 10, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli05', name: 'Ludmila - Cond. Portal da Mata', recurringValue: 180.00, fixedPayDay: 19, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli06', name: 'Leticia - Cond. Vista Bella', recurringValue: 220.00, fixedPayDay: 20, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli07', name: 'Priscila - Vila Virgínia', recurringValue: 190.00, fixedPayDay: 20, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli08', name: 'Michelle - Alto da Boa Vista', recurringValue: 200.00, fixedPayDay: 20, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli09', name: 'Alexandre - Cond. Paineiras', recurringValue: 270.00, fixedPayDay: 20, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli10', name: 'Regina - Fazenda', recurringValue: 150.00, fixedPayDay: 21, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli11', name: 'Luiz - Cond. Madrid', recurringValue: 200.00, fixedPayDay: 22, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli12', name: 'Ana Lúcia - Jd. Canadá', recurringValue: 270.00, fixedPayDay: 24, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli13', name: 'Mariângela - Nova Aliança Sul', recurringValue: 220.00, fixedPayDay: 25, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli14', name: 'Edward - Cond. Vista Bella', recurringValue: 170.00, fixedPayDay: 29, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },
  { id: 'cli15', name: 'Valdirene - Jandaia', recurringValue: 250.00, fixedPayDay: 29, isRecurring: true, targetAccountId: 'acc1', entityId: EntityType.MEI1 },

  // --- MEI 2 (acc2) ---
  { id: 'cli16', name: 'Rodrigo - Cond. Alphaville', recurringValue: 210.00, fixedPayDay: 3, isRecurring: true, targetAccountId: 'acc2', entityId: EntityType.MEI2 },
  { id: 'cli17', name: 'Elisete - Cond. Vista Bella', recurringValue: 180.00, fixedPayDay: 4, isRecurring: true, targetAccountId: 'acc2', entityId: EntityType.MEI2 },
  { id: 'cli18', name: 'Dimas - Cond. Jurucê', recurringValue: 150.00, fixedPayDay: 4, isRecurring: true, targetAccountId: 'acc2', entityId: EntityType.MEI2 },
  { id: 'cli19', name: 'Zé Mario - Cond. Jurucê', recurringValue: 180.00, fixedPayDay: 8, isRecurring: true, targetAccountId: 'acc2', entityId: EntityType.MEI2 },
  { id: 'cli20', name: 'Lucca Santinni - Bonfim', recurringValue: 480.00, fixedPayDay: 8, isRecurring: true, targetAccountId: 'acc2', entityId: EntityType.MEI2 },
  { id: 'cli21', name: 'Denival - Cond. Jurucê', recurringValue: 170.00, fixedPayDay: 13, isRecurring: true, targetAccountId: 'acc2', entityId: EntityType.MEI2 },
  { id: 'cli22', name: 'Eunilson - Cond. Jurucê', recurringValue: 180.00, fixedPayDay: 15, isRecurring: true, targetAccountId: 'acc2', entityId: EntityType.MEI2 },
];

const INITIAL_FAMILY_EXPENSES: RecurringExpense[] = [
  { id: 'exp1', name: 'Casa - Financiamento/Seguro', value: 585.53, dueDay: 20, category: 'Moradia', paymentMethodType: PaymentMethodType.PIX },
  { id: 'exp2', name: 'Internet - Alcans', value: 89.00, dueDay: 12, category: 'Contas de Consumo', paymentMethodType: PaymentMethodType.PIX },
  { id: 'exp3', name: 'Energia - CPFL', value: 150.00, dueDay: 18, category: 'Contas de Consumo', paymentMethodType: PaymentMethodType.PIX },
  { id: 'exp4', name: 'Água e Esgoto - DAE', value: 49.28, dueDay: 20, category: 'Contas de Consumo', paymentMethodType: PaymentMethodType.PIX },
  { id: 'exp5', name: 'Carro - Parcela', value: 225.00, dueDay: 5, category: 'Transporte', paymentMethodType: PaymentMethodType.PIX },
  { id: 'exp6', name: 'MEI 1 - Eliú (DAS)', value: 81.90, dueDay: 20, category: 'Insumos', paymentMethodType: PaymentMethodType.PIX },
  { id: 'exp7', name: 'MEI 2 - Leticia (DAS)', value: 81.90, dueDay: 20, category: 'Insumos', paymentMethodType: PaymentMethodType.PIX },
  { id: 'exp8', name: 'IPVA (Parcela)', value: 288.67, dueDay: 22, category: 'Transporte', paymentMethodType: PaymentMethodType.PIX },
  { id: 'exp9', name: 'IPTU (Parcela)', value: 60.00, dueDay: 24, category: 'Moradia', paymentMethodType: PaymentMethodType.PIX },
];

const App: React.FC = () => {
  // Auth State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
     return localStorage.getItem('g360_auth') === 'true';
  });
  
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('g360_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  
  // Loading & Sync State
  const [isLoading, setIsLoading] = useState(true);
  const [dbConnected, setDbConnected] = useState(false);
  const [isMigrating, setIsMigrating] = useState(false);
  
  const [currentView, setCurrentView] = useState<AppView>(AppView.DASHBOARD);
  
  // REAL-TIME DATA STATES
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [cards, setCards] = useState<Card[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [familyExpenses, setFamilyExpenses] = useState<RecurringExpense[]>([]);
  
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [isNotifOpen, setIsNotifOpen] = useState(false);

  // --- DATA SYNC LOGIC (HYBRID) ---
  useEffect(() => {
    if (!isAuthenticated) return;
    
    setIsLoading(true);

    if (db) {
        // --- CLOUD MODE (FIREBASE) ---
        setDbConnected(true);
        console.log("Starting Firebase Sync...");

        const unsubTrans = onSnapshot(collection(db, 'transactions'), (snapshot) => {
            setTransactions(snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id })) as Transaction[]);
        });
        const unsubClients = onSnapshot(collection(db, 'clients'), (snapshot) => {
            setClients(snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id })) as Client[]);
        });
        const unsubCards = onSnapshot(collection(db, 'cards'), (snapshot) => {
            setCards(snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id })) as Card[]);
        });
        const unsubAccounts = onSnapshot(collection(db, 'accounts'), (snapshot) => {
            setAccounts(snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id })) as Account[]);
        });
        const unsubExpenses = onSnapshot(collection(db, 'familyExpenses'), (snapshot) => {
            setFamilyExpenses(snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id })) as RecurringExpense[]);
            setIsLoading(false);
        });

        return () => {
            unsubTrans();
            unsubClients();
            unsubCards();
            unsubAccounts();
            unsubExpenses();
        };
    } else {
        // --- LOCAL MODE (OFFLINE) ---
        setDbConnected(false);
        console.log("Loading Local Data...");

        const loadLocal = (key: string, setter: any) => {
            const data = localStorage.getItem(`g360_${key}`);
            if (data) setter(JSON.parse(data));
        };

        loadLocal('transactions', setTransactions);
        loadLocal('clients', setClients);
        loadLocal('cards', setCards);
        loadLocal('accounts', setAccounts);
        loadLocal('familyExpenses', setFamilyExpenses);
        
        setIsLoading(false);
    }
  }, [isAuthenticated]);


  const handleLogin = (user: User) => {
      setCurrentUser(user);
      setIsAuthenticated(true);
      localStorage.setItem('g360_auth', 'true');
      localStorage.setItem('g360_user', JSON.stringify(user));
  };

  const handleLogout = () => {
      setCurrentUser(null);
      setIsAuthenticated(false);
      localStorage.removeItem('g360_auth');
      localStorage.removeItem('g360_user');
      setIsUserMenuOpen(false);
  };

  const addAppNotification = (title: string, message: string, type: AppNotification['type']) => {
    setNotifications(prev => {
      if (prev.some(n => n.title === title && n.message === message)) return prev;
      return [{ id: Math.random().toString(36).substr(2, 9), title, message, type, timestamp: new Date(), read: false }, ...prev];
    });
  };

  // --- ACTIONS (DUAL WRITE: FIREBASE OR LOCAL) ---

  const saveToLocal = (key: string, data: any) => {
      localStorage.setItem(`g360_${key}`, JSON.stringify(data));
  };

  const addTransaction = async (newTransactions: Transaction[]) => {
    if (db) {
        // FIREBASE WRITE
        try {
            const batch = writeBatch(db);
            newTransactions.forEach(t => {
                const ref = doc(db, 'transactions', t.id);
                batch.set(ref, t);
                if (t.accountId) {
                    const accRef = doc(db, 'accounts', t.accountId);
                    let modifier = 0;
                    if (t.type === TransactionType.EXPENSE) modifier = -t.value;
                    else if (t.type === TransactionType.INCOME) modifier = t.value;
                    else if (t.type === TransactionType.TRANSFER) modifier = -t.value;

                    if (t.paymentMethodType === PaymentMethodType.PIX || 
                        t.paymentMethodType === PaymentMethodType.CASH || 
                        t.paymentMethodType === PaymentMethodType.TRANSFER) {
                            batch.update(accRef, { balance: increment(modifier) });
                    }
                }
                if (t.type === TransactionType.TRANSFER && t.targetAccountId) {
                    const targetRef = doc(db, 'accounts', t.targetAccountId);
                    batch.update(targetRef, { balance: increment(t.value) });
                }
            });
            await batch.commit();
        } catch (e) {
            addAppNotification('Erro', 'Falha na nuvem.', 'alert');
        }
    } else {
        // LOCAL WRITE
        const updatedTransactions = [...transactions, ...newTransactions];
        setTransactions(updatedTransactions);
        saveToLocal('transactions', updatedTransactions);

        // Handle Balances Locally
        let updatedAccounts = [...accounts];
        newTransactions.forEach(t => {
             if (t.accountId) {
                 const accIndex = updatedAccounts.findIndex(a => a.id === t.accountId);
                 if (accIndex > -1) {
                     let modifier = 0;
                     if (t.type === TransactionType.EXPENSE) modifier = -t.value;
                     else if (t.type === TransactionType.INCOME) modifier = t.value;
                     else if (t.type === TransactionType.TRANSFER) modifier = -t.value;

                     if (t.paymentMethodType === PaymentMethodType.PIX || 
                         t.paymentMethodType === PaymentMethodType.CASH || 
                         t.paymentMethodType === PaymentMethodType.TRANSFER) {
                             updatedAccounts[accIndex] = { 
                                 ...updatedAccounts[accIndex], 
                                 balance: updatedAccounts[accIndex].balance + modifier 
                             };
                     }
                 }
             }
             if (t.type === TransactionType.TRANSFER && t.targetAccountId) {
                  const targetIndex = updatedAccounts.findIndex(a => a.id === t.targetAccountId);
                  if (targetIndex > -1) {
                      updatedAccounts[targetIndex] = {
                          ...updatedAccounts[targetIndex],
                          balance: updatedAccounts[targetIndex].balance + t.value
                      };
                  }
             }
        });
        setAccounts(updatedAccounts);
        saveToLocal('accounts', updatedAccounts);
    }

    // Common Feedback
    if(newTransactions.length === 1 && newTransactions[0].type === TransactionType.TRANSFER) {
        addAppNotification('Transferência Realizada', `R$ ${newTransactions[0].value} transferidos.`, 'info');
    } else {
        addAppNotification('Sucesso', `${newTransactions.length} lançamento(s) salvos.`, 'success');
    }
  };

  const handleClientPayment = (t: Transaction) => {
    addTransaction([t]);
    addAppNotification('Pagamento', `Recebimento de ${t.description} confirmado.`, 'success');
  };

  const handleSaveCard = async (cardData: Card) => {
      if (db) {
          // setDoc with {merge: true} handles both Create and Update if ID exists
          await setDoc(doc(db, 'cards', cardData.id), cardData, { merge: true });
      } else {
          // Local Update or Add
          const existingIndex = cards.findIndex(c => c.id === cardData.id);
          let updatedCards = [...cards];
          if (existingIndex >= 0) {
              updatedCards[existingIndex] = cardData;
          } else {
              updatedCards.push(cardData);
          }
          setCards(updatedCards);
          saveToLocal('cards', updatedCards);
      }
      addAppNotification('Cartão Salvo', `${cardData.name} atualizado.`, 'success');
  };

  const handleSaveAccount = async (accountData: Account) => {
      if (db) {
          await setDoc(doc(db, 'accounts', accountData.id), accountData, { merge: true });
      } else {
          const existingIndex = accounts.findIndex(a => a.id === accountData.id);
          let updatedAccounts = [...accounts];
          if (existingIndex >= 0) {
              updatedAccounts[existingIndex] = accountData;
          } else {
              updatedAccounts.push(accountData);
          }
          setAccounts(updatedAccounts);
          saveToLocal('accounts', updatedAccounts);
      }
      addAppNotification('Conta Salva', `${accountData.name} atualizada.`, 'success');
  };

  const handleAddClient = async (newClient: Client) => {
      if (db) {
          await setDoc(doc(db, 'clients', newClient.id), newClient);
      } else {
          const updated = [...clients, newClient];
          setClients(updated);
          saveToLocal('clients', updated);
      }
      addAppNotification('Cliente Adicionado', `${newClient.name} salvo.`, 'success');
  }

  const handleAddFamilyExpense = async (newExpense: RecurringExpense) => {
      if (db) {
          await setDoc(doc(db, 'familyExpenses', newExpense.id), newExpense);
      } else {
          const updated = [...familyExpenses, newExpense];
          setFamilyExpenses(updated);
          saveToLocal('familyExpenses', updated);
      }
      addAppNotification('Despesa Fixa', `${newExpense.name} salva.`, 'success');
  };

  const handlePayFamilyExpense = (transactions: Transaction[]) => {
      addTransaction(transactions);
      addAppNotification('Pagamento Registrado', `${transactions[0].description} pago.`, 'success');
  }

  const handleDeleteFamilyExpense = async (id: string) => {
      if (db) {
          await deleteDoc(doc(db, 'familyExpenses', id));
      } else {
          const updated = familyExpenses.filter(e => e.id !== id);
          setFamilyExpenses(updated);
          saveToLocal('familyExpenses', updated);
      }
      addAppNotification('Despesa Removida', 'Item excluído.', 'success');
  };

  // MIGRATION HELPER
  const runInitialMigration = async () => {
    setIsMigrating(true);
    if (db) {
        try {
            const batch = writeBatch(db);
            INITIAL_ACCOUNTS.forEach(acc => batch.set(doc(db, 'accounts', acc.id), acc));
            INITIAL_CARDS.forEach(c => batch.set(doc(db, 'cards', c.id), c));
            // Only adds expenses if the array is not empty
            INITIAL_FAMILY_EXPENSES.forEach(e => batch.set(doc(db, 'familyExpenses', e.id), e));
            INITIAL_CLIENTS.forEach(c => batch.set(doc(db, 'clients', c.id), c));
            await batch.commit();
            addAppNotification('Banco de Dados', 'Instalação completa!', 'success');
        } catch(e) {
            console.error(e);
            addAppNotification('Erro', 'Falha na migração.', 'alert');
        }
    } else {
        // Local Migration
        setAccounts(INITIAL_ACCOUNTS);
        saveToLocal('accounts', INITIAL_ACCOUNTS);
        setCards(INITIAL_CARDS);
        saveToLocal('cards', INITIAL_CARDS);
        setFamilyExpenses(INITIAL_FAMILY_EXPENSES);
        saveToLocal('familyExpenses', INITIAL_FAMILY_EXPENSES);
        setClients(INITIAL_CLIENTS);
        saveToLocal('clients', INITIAL_CLIENTS);
    }
    setIsMigrating(false);
  };

  const renderView = () => {
    switch(currentView) {
      case AppView.DASHBOARD:
        return <Dashboard 
                  transactions={transactions} 
                  cards={cards} 
                  accounts={accounts} 
                  isLoading={isLoading} 
               />;
      case AppView.WALLET:
        return <Wallet 
                  accounts={accounts} 
                  cards={cards} 
                  transactions={transactions} 
                  onSaveCard={handleSaveCard} 
                  onSaveAccount={handleSaveAccount}
                  isLoading={isLoading} 
               />;
      case AppView.TRANSACTIONS:
        return <Transactions transactions={transactions} onAddTransaction={addTransaction} cards={cards} accounts={accounts} isLoading={isLoading} />;
      case AppView.CLIENTS:
        return <Clients clients={clients} accounts={accounts} transactions={transactions} onGeneratePayment={handleClientPayment} onAddClient={handleAddClient} onAddTransaction={addTransaction} isLoading={isLoading} />;
      case AppView.FAMILY_MGT:
        return <FamilyManagement 
                  expenses={familyExpenses} 
                  transactions={transactions} 
                  accounts={accounts} 
                  cards={cards} 
                  onAddExpense={handleAddFamilyExpense} 
                  onPayExpense={handlePayFamilyExpense} 
                  onDeleteExpense={handleDeleteFamilyExpense}
                  isLoading={isLoading}
               />;
      default:
        return <Dashboard transactions={transactions} cards={cards} accounts={accounts} isLoading={isLoading} />;
    }
  };

  if (!isAuthenticated) {
      return <Login users={USERS} onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex animate-in fade-in duration-500">
      <Sidebar 
        currentView={currentView} 
        onChangeView={setCurrentView} 
        isMobileOpen={isMobileNavOpen}
        setIsMobileOpen={setIsMobileNavOpen}
      />
      
      <main className="flex-1 md:ml-20 lg:ml-20 xl:ml-20 p-4 md:p-8 overflow-y-auto h-screen relative transition-all duration-300">
        
        <div className="md:hidden flex items-center gap-3 mb-6">
            <button onClick={() => setIsMobileNavOpen(true)} className="p-2 bg-white rounded-lg border border-slate-200 text-slate-600">
                <Menu size={24} />
            </button>
            <h1 className="font-bold text-slate-800 text-lg">Gestão360 <span className="text-xs text-white bg-indigo-600 px-1.5 py-0.5 rounded">v2.0</span></h1>
        </div>

        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-800 hidden md:block">
                {currentView === AppView.DASHBOARD && 'Visão Geral'}
                {currentView === AppView.WALLET && 'Minha Carteira'}
                {currentView === AppView.TRANSACTIONS && 'Livro Caixa'}
                {currentView === AppView.CLIENTS && 'Gestão Empresarial'}
                {currentView === AppView.FAMILY_MGT && 'Gestão Familiar'}
            </h1>
            <p className="text-slate-500 text-sm hidden md:block">Controle unificado: Pessoal + MEI 1 + MEI 2</p>
          </div>
          <div className="flex items-center gap-4 md:gap-6">
             <div className="text-right mr-2 hidden md:block">
                <p className="text-xs font-bold text-slate-500 uppercase">Mês Vigente (Ref)</p>
                <p className="text-emerald-600 font-bold">{getFinancialMonth(new Date().toISOString().split('T')[0])}</p>
             </div>

             {/* CLOUD STATUS INDICATOR */}
             <div className={`hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full border shadow-sm transition-colors ${dbConnected ? 'bg-white border-slate-200' : 'bg-orange-50 border-orange-200'}`} title={dbConnected ? "Sincronizado na Nuvem" : "Modo Local (Offline)"}>
                {isLoading ? (
                    <Loader2 size={14} className="text-indigo-500 animate-spin" />
                ) : dbConnected ? (
                    <Cloud size={14} className="text-emerald-500" />
                ) : (
                    <HardDrive size={14} className="text-orange-500" />
                )}
                <span className={`text-[10px] font-bold uppercase ${dbConnected ? 'text-slate-600' : 'text-orange-700'}`}>
                    {isLoading ? 'Sync...' : dbConnected ? 'Online' : 'Local'}
                </span>
             </div>

             {/* Notifications */}
             <div className="relative z-30">
                <button 
                  onClick={() => setIsNotifOpen(!isNotifOpen)}
                  className="relative p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
                >
                  <Bell size={24} />
                  {notifications.filter(n => !n.read).length > 0 && (
                    <span className="absolute top-1 right-1 h-4 w-4 bg-red-500 text-white text-[10px] font-bold flex items-center justify-center rounded-full ring-2 ring-white">
                      {notifications.filter(n => !n.read).length}
                    </span>
                  )}
                </button>
                {isNotifOpen && (
                  <div className="absolute right-0 mt-3 w-72 bg-white rounded-xl shadow-xl border border-slate-100 p-4 z-50 animate-in fade-in slide-in-from-top-2">
                     <h4 className="font-bold text-slate-700 mb-2">Notificações</h4>
                     {notifications.length === 0 && <p className="text-sm text-slate-400">Sem notificações.</p>}
                     {notifications.map(n => (
                         <div key={n.id} className="border-b border-slate-50 py-2 last:border-0">
                             <p className="text-xs font-bold text-slate-700">{n.title}</p>
                             <p className="text-xs text-slate-500">{n.message}</p>
                         </div>
                     ))}
                  </div>
                )}
             </div>

             {/* USER SWITCHER */}
             <div className="relative z-30">
               <button 
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 hover:bg-white hover:shadow-sm p-1 pr-3 rounded-full transition-all border border-transparent hover:border-slate-100"
               >
                  <div className={`h-10 w-10 ${currentUser?.color || 'bg-slate-500'} rounded-full flex items-center justify-center text-white font-bold border-2 border-white shadow-sm`}>
                    {currentUser?.initials || '??'}
                  </div>
                  <ChevronDown size={14} className="text-slate-400 hidden md:block" />
               </button>

               {isUserMenuOpen && (
                  <div className="absolute right-0 mt-3 w-64 bg-white rounded-xl shadow-xl border border-slate-100 p-2 z-50 animate-in fade-in slide-in-from-top-2">
                      <div className="px-3 py-2 border-b border-slate-50 mb-1">
                          <p className="text-xs text-slate-400 font-bold uppercase">Usuário Atual</p>
                          <p className="font-bold text-slate-800">{currentUser?.name}</p>
                      </div>
                      
                      {USERS.map(user => (
                        <button 
                          key={user.id}
                          onClick={() => {
                            setCurrentUser(user);
                            localStorage.setItem('g360_user', JSON.stringify(user));
                            setIsUserMenuOpen(false);
                            addAppNotification('Usuário Alternado', `Bem-vindo(a), ${user.name}!`, 'info');
                          }}
                          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-sm font-medium ${currentUser?.id === user.id ? 'bg-slate-50 text-slate-800' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'}`}
                        >
                           <div className={`w-6 h-6 rounded-full ${user.color} flex items-center justify-center text-[10px] text-white`}>
                              {user.initials}
                           </div>
                           {user.name}
                        </button>
                      ))}

                      <div className="border-t border-slate-50 mt-1 pt-1">
                        <button 
                          onClick={handleLogout}
                          className="w-full flex items-center gap-3 px-3 py-2 text-rose-600 hover:bg-rose-50 rounded-lg text-sm font-medium transition-colors"
                        >
                           <LogOut size={16} /> Sair
                        </button>
                      </div>
                  </div>
               )}
             </div>
          </div>
        </header>

        {/* --- EMPTY STATE SETUP WIZARD --- */}
        {!isLoading && accounts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[60vh] text-center animate-in fade-in slide-in-from-bottom-5">
                <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500"></div>
                    <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                        <Database size={32} />
                    </div>
                    <h2 className="text-2xl font-bold text-slate-800 mb-2">Banco de Dados Vazio</h2>
                    <p className="text-slate-500 mb-8">
                        Detectamos que você conectou ao Firebase, mas ainda não existem dados. Deseja instalar as contas e cartões iniciais agora?
                    </p>
                    
                    <button 
                        onClick={runInitialMigration}
                        disabled={isMigrating}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-emerald-900/10 transition-all flex items-center justify-center gap-2 group"
                    >
                        {isMigrating ? (
                            <Loader2 size={20} className="animate-spin" />
                        ) : (
                            <Rocket size={20} className="group-hover:-translate-y-1 transition-transform" />
                        )}
                        {isMigrating ? 'Instalando...' : 'Inicializar Sistema Agora'}
                    </button>
                    
                    <div className="mt-4 pt-4 border-t border-slate-100 text-xs text-slate-400">
                        Isso irá criar: 10 Contas e 4 Cartões.
                    </div>
                </div>
            </div>
        ) : (
            renderView()
        )}
        
      </main>
    </div>
  );
};

export default App;