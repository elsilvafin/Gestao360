import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// ------------------------------------------------------------------
// CONFIGURAÇÃO DO FIREBASE
// ------------------------------------------------------------------
const firebaseConfig = {
  apiKey: "AIzaSyA7SPNsxKtpdvyIDak8u3WTRZyljHTlxBs",
  authDomain: "gestao360-b2c92.firebaseapp.com",
  projectId: "gestao360-b2c92",
  storageBucket: "gestao360-b2c92.firebasestorage.app",
  messagingSenderId: "147905752440",
  appId: "1:147905752440:web:426ae457490edf6ee8ec8d"
};

// Inicialização segura
let app;
let dbInstance = null;

try {
    // Validação simples: verifica se a config existe e se não é um placeholder
    const isValidConfig = firebaseConfig.apiKey && 
                          firebaseConfig.apiKey.length > 10 && 
                          firebaseConfig.apiKey !== "SUA_API_KEY_AQUI";

    if (isValidConfig) {
        app = initializeApp(firebaseConfig);
        dbInstance = getFirestore(app);
        console.log("✅ Firebase: Conexão inicializada.");
    } else {
        console.warn("⚠️ Firebase: Chaves não configuradas. O app funcionará em modo LOCAL.");
    }
} catch (error) {
    console.error("❌ Firebase: Falha na inicialização.", error);
    // DbInstance permanece null, forçando o App.tsx a usar localStorage
}

export const db = dbInstance;