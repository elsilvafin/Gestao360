import React, { useMemo, useState } from 'react';
import { Transaction, EntityType, TransactionType, PaymentStatus, Card, Account } from '../types';
import { 
  getFinancialMonth, 
  formatCurrency, 
  getMonthName, 
  navigateMonth, 
  formatDateBr,
  getDaysInMonth,
  getFirstDayOfWeek
} from '../utils/dateHelpers';
import { 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis
} from 'recharts';
import { 
  ArrowUpCircle, 
  ArrowDownCircle, 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Sun,
  X,
  CreditCard,
  History,
  TrendingUp,
  AlertTriangle
} from 'lucide-react';
import { Loading } from '../components/Loading';

interface DashboardProps {
  transactions: Transaction[];
  cards?: Card[]; // New in v2.0
  accounts?: Account[]; // New in v2.0
  isLoading?: boolean;
}

// Expanded Color Palette for Categories
const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#6366f1', '#14b8a6', '#06b6d4', '#f97316'];
const PIE_COLORS_BALANCE = ['#10b981', '#f43f5e']; // Green for Income, Red for Expense

type ViewMode = 'DEFAULT' | 'TODAY' | 'CALENDAR';

export const Dashboard: React.FC<DashboardProps> = ({ transactions, cards = [], accounts = [], isLoading }) => {
  // Determine the default filter to be the current financial month
  const today = new Date().toISOString().split('T')[0];
  const currentRefMonth = getFinancialMonth(today);

  const [selectedMonth, setSelectedMonth] = useState<string>(currentRefMonth);
  const [viewMode, setViewMode] = useState<ViewMode>('DEFAULT');

  // Filter Data based on Month Selection (Standard Dashboard Logic)
  const filteredData = useMemo(() => {
    return transactions.filter(t => t.referenceMonth === selectedMonth);
  }, [transactions, selectedMonth]);

  // Calculate Aggregates
  const stats = useMemo(() => {
    const income = filteredData
      .filter(t => t.type === TransactionType.INCOME)
      .reduce((acc, curr) => acc + curr.value, 0);
    const expense = filteredData
      .filter(t => t.type === TransactionType.EXPENSE)
      .reduce((acc, curr) => acc + curr.value, 0);
    
    // Calculate Forecast (Simulated: Balance - Pending Expenses for this month)
    const pendingExpenses = filteredData
        .filter(t => t.type === TransactionType.EXPENSE && t.status === PaymentStatus.PENDING)
        .reduce((acc, curr) => acc + curr.value, 0);

    return {
      income,
      expense,
      balance: income - expense,
      forecast: (income - expense) - pendingExpenses // Highly simplified forecast
    };
  }, [filteredData]);

  // Balance Pie Data
  const balancePieData = [
    { name: 'Entradas', value: stats.income },
    { name: 'Saídas', value: stats.expense },
  ];

  // Category Data (Expenses Only)
  const categoryData = useMemo(() => {
    const expenses = filteredData.filter(t => t.type === TransactionType.EXPENSE && t.category !== 'Investimentos');
    const catMap = new Map<string, number>();
    expenses.forEach(t => {
      const current = catMap.get(t.category) || 0;
      catMap.set(t.category, current + t.value);
    });
    return Array.from(catMap.entries())
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value); // Sort Descending
  }, [filteredData]);

  // --- v2.0 CARDS WIDGET DATA ---
  const cardsSummary = useMemo(() => {
      return cards.map(card => {
          const cardExpenses = transactions.filter(t => 
              t.cardId === card.id && 
              t.referenceMonth === selectedMonth &&
              t.type === TransactionType.EXPENSE
          );
          const totalUsed = cardExpenses.reduce((acc, t) => acc + t.value, 0);
          const percentage = Math.min((totalUsed / card.limit) * 100, 100);
          return {
              ...card,
              totalUsed,
              percentage
          };
      }).sort((a, b) => b.percentage - a.percentage); // Sort by highest usage %
  }, [cards, transactions, selectedMonth]);

  // --- v2.0 RECENT ACTIVITY DATA ---
  const recentActivity = useMemo(() => {
      // Get last 5 transactions regardless of month, but lets stick to selected month context or global
      // Use global recent to show what happened lately
      return [...transactions]
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 5);
  }, [transactions]);


  // Helper for Real Calendar View
  const calendarGrid = useMemo(() => {
    const [yearStr, monthStr] = selectedMonth.split('-');
    const year = parseInt(yearStr);
    const month = parseInt(monthStr);

    const daysCount = getDaysInMonth(year, month);
    const startDayOfWeek = getFirstDayOfWeek(year, month);

    const grid = [];

    for (let i = 0; i < startDayOfWeek; i++) {
        grid.push({ type: 'EMPTY', key: `empty-${i}` });
    }

    for (let i = 1; i <= daysCount; i++) {
      const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
      const dayTransactions = transactions.filter(t => t.date === dateStr);
      const dayIncome = dayTransactions.filter(t => t.type === TransactionType.INCOME).reduce((sum, t) => sum + t.value, 0);
      const dayExpense = dayTransactions.filter(t => t.type === TransactionType.EXPENSE).reduce((sum, t) => sum + t.value, 0);
      
      grid.push({
        type: 'DAY',
        key: dateStr,
        date: dateStr,
        dayNumber: i,
        income: dayIncome,
        expense: dayExpense,
        hasTrans: dayTransactions.length > 0
      });
    }

    return grid;
  }, [selectedMonth, transactions]);

  if (isLoading) {
    return <Loading />;
  }

  return (
    <div className="space-y-6">
      
      {/* 1. Header Navigation */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        
        {/* Month Navigator */}
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setSelectedMonth(navigateMonth(selectedMonth, -1))}
            className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-emerald-600 transition-colors"
          >
            <ChevronLeft size={20} />
          </button>
          
          <div className="text-center">
            <h2 className="text-lg font-bold text-slate-800 uppercase tracking-wide">
              {getMonthName(selectedMonth)}
            </h2>
            <p className="text-[10px] text-slate-400 font-medium">Ciclo Financeiro</p>
          </div>

          <button 
            onClick={() => setSelectedMonth(navigateMonth(selectedMonth, 1))}
            className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-emerald-600 transition-colors"
          >
            <ChevronRight size={20} />
          </button>
        </div>

        {/* View Toggles */}
        <div className="flex gap-2">
          <button 
            onClick={() => setViewMode(viewMode === 'TODAY' ? 'DEFAULT' : 'TODAY')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all ${
              viewMode === 'TODAY' 
              ? 'bg-blue-100 text-blue-700' 
              : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
             <Sun size={16} /> <span className="hidden md:inline">Hoje</span>
          </button>
          <button 
             onClick={() => setViewMode(viewMode === 'CALENDAR' ? 'DEFAULT' : 'CALENDAR')}
             className={`px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all ${
              viewMode === 'CALENDAR' 
              ? 'bg-indigo-100 text-indigo-700' 
              : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
             <CalendarIcon size={16} /> <span className="hidden md:inline">Calendário</span>
          </button>
        </div>
      </div>

      {/* VIEW: TODAY */}
      {viewMode === 'TODAY' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 animate-in fade-in slide-in-from-top-2">
            <div className="flex justify-between items-center mb-4">
               <h3 className="font-bold text-slate-800 flex items-center gap-2"><Sun size={20} className="text-orange-500"/> Lançamentos de Hoje ({formatDateBr(today)})</h3>
               <button onClick={() => setViewMode('DEFAULT')}><X size={20} className="text-slate-400 hover:text-slate-600"/></button>
            </div>
            {transactions.filter(t => t.date === today).length === 0 ? (
               <p className="text-center text-slate-400 py-8">Nenhum lançamento registrado hoje.</p>
            ) : (
              <div className="space-y-3">
                 {transactions.filter(t => t.date === today).map(t => (
                   <div key={t.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg border border-slate-100">
                      <div>
                        <p className="font-semibold text-slate-800">{t.description}</p>
                        <p className="text-xs text-slate-500">{t.category} • {t.paymentMethod}</p>
                      </div>
                      <span className={`font-bold ${t.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-rose-600'}`}>
                         {t.type === TransactionType.INCOME ? '+' : '-'} {formatCurrency(t.value)}
                      </span>
                   </div>
                 ))}
              </div>
            )}
        </div>
      )}

      {/* VIEW: CALENDAR */}
      {viewMode === 'CALENDAR' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 animate-in fade-in slide-in-from-top-2">
            <div className="grid grid-cols-7 gap-1 md:gap-2">
                {['D','S','T','Q','Q','S','S'].map(d => (
                   <div key={d} className="text-center text-xs font-bold text-slate-400 uppercase py-2">{d}</div>
                ))}
                {calendarGrid.map((item) => {
                  if (item.type === 'EMPTY') return <div key={item.key} className="bg-transparent min-h-[60px]"></div>;
                  const isToday = item.date === today;
                  return (
                    <div key={item.key} className={`min-h-[60px] md:min-h-[80px] p-1 rounded-lg border flex flex-col justify-between transition-colors ${isToday ? 'bg-blue-50 border-blue-300 ring-1 ring-blue-300' : 'bg-slate-50 border-slate-100'}`}>
                        <span className={`text-xs font-bold self-center md:self-start ${isToday ? 'text-blue-700' : 'text-slate-500'}`}>{item.dayNumber}</span>
                        {item.hasTrans && (
                          <div className="w-full space-y-1 mt-1">
                             {item.income > 0 && <div className="w-full bg-emerald-100 text-emerald-700 text-[9px] px-1 rounded truncate">+ {formatCurrency(item.income)}</div>}
                             {item.expense > 0 && <div className="w-full bg-rose-100 text-rose-700 text-[9px] px-1 rounded truncate">- {formatCurrency(item.expense)}</div>}
                          </div>
                        )}
                    </div>
                  );
                })}
            </div>
        </div>
      )}

      {/* VIEW: DEFAULT DASHBOARD v2.0 */}
      {viewMode === 'DEFAULT' && (
        <div className="space-y-6 animate-in fade-in">
          
          {/* 1. KPIs Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-5 rounded-xl border border-emerald-100 shadow-sm relative overflow-hidden">
                  <p className="text-xs font-bold text-slate-500 uppercase mb-1">Entradas (Mês)</p>
                  <h3 className="text-2xl font-bold text-emerald-600">{formatCurrency(stats.income)}</h3>
                  <div className="absolute right-[-10px] bottom-[-10px] opacity-10"><ArrowUpCircle size={80} className="text-emerald-500"/></div>
              </div>
              <div className="bg-white p-5 rounded-xl border border-rose-100 shadow-sm relative overflow-hidden">
                  <p className="text-xs font-bold text-slate-500 uppercase mb-1">Saídas (Mês)</p>
                  <h3 className="text-2xl font-bold text-rose-600">{formatCurrency(stats.expense)}</h3>
                  <div className="absolute right-[-10px] bottom-[-10px] opacity-10"><ArrowDownCircle size={80} className="text-rose-500"/></div>
              </div>
              <div className={`bg-white p-5 rounded-xl border shadow-sm relative overflow-hidden ${stats.balance >= 0 ? 'border-indigo-100' : 'border-orange-100'}`}>
                  <p className="text-xs font-bold text-slate-500 uppercase mb-1">Balanço Líquido</p>
                  <h3 className={`text-2xl font-bold ${stats.balance >= 0 ? 'text-indigo-600' : 'text-orange-600'}`}>{formatCurrency(stats.balance)}</h3>
                  <div className={`absolute right-[-10px] bottom-[-10px] opacity-10 ${stats.balance >= 0 ? 'text-indigo-500' : 'text-orange-500'}`}><TrendingUp size={80}/></div>
              </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* 2. Main Chart (Left - 2/3 width) */}
            <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 p-6 flex flex-col">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-slate-800">Fluxo de Caixa</h3>
                    <div className="flex gap-4 text-xs">
                        <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-emerald-500"></div>Entrada</div>
                        <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-rose-500"></div>Saída</div>
                    </div>
                </div>
                <div className="h-[250px] w-full">
                     {/* Simplified Visualization using Pie for MVP, ideal would be BarChart over time */}
                     <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={[{name: 'Total', Income: stats.income, Expense: stats.expense}]} layout="vertical" barSize={40}>
                        <XAxis type="number" hide />
                        <YAxis type="category" dataKey="name" hide />
                        <Tooltip cursor={{fill: 'transparent'}} formatter={(val: number) => formatCurrency(val)}/>
                        <Bar dataKey="Income" fill="#10b981" radius={[0, 4, 4, 0]} background={{ fill: '#f1f5f9' }} />
                        <Bar dataKey="Expense" fill="#f43f5e" radius={[0, 4, 4, 0]} background={{ fill: '#f1f5f9' }} />
                      </BarChart>
                    </ResponsiveContainer>
                    <div className="mt-4 flex justify-center">
                        <div className="text-center">
                            <p className="text-xs text-slate-400 font-bold uppercase">Resultado do Período</p>
                            <p className={`text-xl font-bold ${stats.balance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                                {formatCurrency(stats.balance)}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* 3. Cards Summary Widget (Right - 1/3 width) */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-0 overflow-hidden flex flex-col">
                <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                    <h3 className="font-bold text-slate-700 flex items-center gap-2">
                        <CreditCard size={18} /> Faturas ({getMonthName(selectedMonth).substring(0,3)})
                    </h3>
                </div>
                <div className="p-4 space-y-4 flex-1 overflow-y-auto max-h-[300px]">
                    {cardsSummary.length === 0 && <p className="text-center text-slate-400 text-sm">Nenhum cartão cadastrado.</p>}
                    {cardsSummary.map(card => (
                        <div key={card.id}>
                            <div className="flex justify-between text-xs mb-1">
                                <span className="font-bold text-slate-700">{card.name}</span>
                                <span className="text-slate-500">{formatCurrency(card.totalUsed)}</span>
                            </div>
                            <div className="w-full bg-slate-100 rounded-full h-1.5">
                                <div 
                                    className={`h-1.5 rounded-full transition-all duration-500 ${card.percentage > 90 ? 'bg-red-500' : card.percentage > 70 ? 'bg-orange-500' : 'bg-indigo-500'}`} 
                                    style={{ width: `${card.percentage}%` }}
                                ></div>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
                     <p className="text-[10px] text-slate-400">Vencimentos próximos ao dia 20-25</p>
                </div>
            </div>
          </div>

          {/* 4. Recent Activity Row */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
             <div className="p-4 border-b border-slate-100 flex items-center gap-2">
                <History size={18} className="text-slate-400"/>
                <h3 className="font-bold text-slate-800">Últimas Movimentações (Global)</h3>
             </div>
             <div className="divide-y divide-slate-50">
                {recentActivity.map(t => (
                    <div key={t.id} className="p-3 flex justify-between items-center hover:bg-slate-50 transition-colors">
                        <div className="flex items-center gap-3">
                             <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${t.type === TransactionType.INCOME ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                                 {t.type === TransactionType.INCOME ? 'IN' : 'OUT'}
                             </div>
                             <div>
                                 <p className="text-sm font-bold text-slate-700">{t.description}</p>
                                 <p className="text-[10px] text-slate-400">{formatDateBr(t.date)} • {t.category}</p>
                             </div>
                        </div>
                        <span className={`text-sm font-bold ${t.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-slate-600'}`}>
                            {t.type === TransactionType.EXPENSE ? '-' : '+'} {formatCurrency(t.value)}
                        </span>
                    </div>
                ))}
             </div>
          </div>

        </div>
      )}
    </div>
  );
};