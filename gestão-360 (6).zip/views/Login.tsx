import React from 'react';
import { User } from '../types';
import { Wallet, ShieldCheck, ArrowRight } from 'lucide-react';

interface LoginProps {
  users: User[];
  onLogin: (user: User) => void;
}

export const Login: React.FC<LoginProps> = ({ users, onLogin }) => {
  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
          <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-emerald-600/20 rounded-full blur-[100px]"></div>
          <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-blue-600/20 rounded-full blur-[100px]"></div>
      </div>

      <div className="w-full max-w-4xl z-10 flex flex-col items-center animate-in fade-in slide-in-from-bottom-4 duration-700">
        
        {/* Logo Section */}
        <div className="mb-12 text-center">
             <div className="inline-flex items-center justify-center p-4 bg-slate-800 rounded-2xl mb-6 shadow-2xl shadow-emerald-900/20 ring-1 ring-slate-700">
                <Wallet size={48} className="text-emerald-500" />
             </div>
             <h1 className="text-4xl md:text-5xl font-bold text-white mb-3 tracking-tight">Gestão360</h1>
             <p className="text-slate-400 text-lg">Sistema de Gestão Patrimonial e Familiar</p>
        </div>

        {/* Profile Selector */}
        <div className="w-full max-w-2xl">
            <h2 className="text-center text-slate-300 text-sm uppercase tracking-widest font-bold mb-8">Quem está acessando?</h2>
            
            <div className="flex flex-wrap justify-center gap-6 md:gap-10">
                {users.map(user => (
                    <button 
                        key={user.id}
                        onClick={() => onLogin(user)}
                        className="group flex flex-col items-center gap-4 transition-all duration-300 focus:outline-none"
                    >
                        <div className={`
                            w-24 h-24 md:w-32 md:h-32 rounded-full ${user.color} 
                            flex items-center justify-center text-3xl md:text-4xl font-bold text-white shadow-2xl
                            border-4 border-slate-800 group-hover:border-emerald-500 group-hover:scale-110 
                            transition-all duration-300 relative overflow-hidden
                        `}>
                            {user.initials}
                            {/* Hover shine effect */}
                            <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/10 to-white/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
                        </div>
                        <span className="text-slate-400 group-hover:text-white font-medium text-lg transition-colors">{user.name}</span>
                    </button>
                ))}

                {/* Add Profile Placeholder (Visual only) */}
                <button className="group flex flex-col items-center gap-4 opacity-50 hover:opacity-100 transition-all duration-300">
                     <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-slate-800 border-2 border-dashed border-slate-600 flex items-center justify-center text-slate-500 group-hover:border-slate-400 group-hover:text-slate-300 transition-all">
                        <span className="text-4xl font-light">+</span>
                     </div>
                     <span className="text-slate-500 text-sm">Adicionar</span>
                </button>
            </div>
        </div>

        {/* Footer Info */}
        <div className="mt-16 flex items-center gap-2 text-slate-500 text-xs bg-slate-800/50 px-4 py-2 rounded-full border border-slate-700/50">
            <ShieldCheck size={14} className="text-emerald-500"/>
            <span>Ambiente Seguro • v1.0.0 Beta</span>
        </div>

      </div>
    </div>
  );
};